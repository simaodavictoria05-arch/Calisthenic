# Calisthenics Engine — Android offline app

This project packages the provided Calisthenics Engine HTML as a native Android app shell. The interface and its local HTML/JavaScript assets are bundled inside the app; no website hosting or Chrome tab is needed, and no network permission is requested. LocalStorage is enabled for profile/history persistence.

## Build the APK
1. Install Android Studio on a computer and make sure Android SDK Platform 35 is installed.
2. Open this `CalisthenicsEngineAndroid` folder as a project.
3. Allow Gradle sync to finish (the Android Gradle Plugin may be downloaded the first time).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer that APK to the Android phone, allow installation from that file manager when prompted, and install it.

## Notes
- Minimum Android version: Android 6.0 (API 23).
- App name: Calisthenics Engine.
- The app content is bundled locally and can open without internet.
- Voice output depends on the speech synthesis voices installed/enabled on the Android device and the WebView version.
- This delivery is the Android Studio project, not a precompiled APK; this environment does not have the Android SDK/Gradle build tools needed to compile and sign an APK here.
